### Analyzing Actuary Data to Predict Outcomes for Insurance Policies
library(tidyverse)
library(dslabs)
death_prob
options(digits = 3)

# The Break-Even point for Life Insurance
# The loss in the event of the policy holder's death is -$200,000.
# What is the break-even point for the expected value of the company's net profit 
# on one policy for a 60 year old male?
a <- -200000
b <- 2319 # adjust this value to test the break-even point
p <- death_prob %>%
  filter(sex == "Male" & age == "60") %>%
  pull(prob)
p
S <- a*p + b*(1-p)
S

# Setting an Annual Goal for Insurance Rates to Remain Profitable
# If we were managing 1,000 policies for 50-year-old females, with $150,000 life 
# insurance policies.  How much should we charge to maintain our annual profit 
# of $1,000,000?
p_female <- death_prob %>%
  filter(sex == "Female" & age == "60") %>%
  pull(prob)
p <- p_female
mu_sum <- 1000000
n <- 1000
a <- -150000

b <- (mu_sum/n-a*p)/(1-p)
b

# Now, lets determine what the probability of losing money from the previously 
# mentioned scenario using the Central Limit Theorem.
n <- 1000
a <- -150000
b <- 2026
p <- death_prob %>%
  filter(sex == "Female" & age == "50") %>%
  pull(prob)
p

p <- p_female
mu_sum <- 700000
n <- 1000
a <- -150000
b <- (mu_sum/n-a*p)/(1-p)
b
sigma_sum <- sqrt(n)*abs(b-a)*sqrt(p*(1-p))
sigma_sum

pnorm(0, mu_sum, sigma_sum)

