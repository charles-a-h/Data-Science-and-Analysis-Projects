# Confounding: Multivariate Linear Regression: Baseball Data Predictions 
library(tidyverse)
library(Lahman)
library(dslabs)
ds_theme_set()
Teams

# Regression line computations for HRs and wins
homeruns <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(HR_per_game = HR / G) %>% 
  select(HR_per_game)

wins <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(wins_per_game = W / G) %>% 
  select(wins_per_game)

mu_x <- sapply(homeruns, mean)
mu_y <- sapply(wins, mean)
s_x <- sapply(homeruns, sd)
s_y <- sapply(wins, sd)
r <- cor(homeruns, wins)
m <- r * s_y/s_x
b <- mu_y - m*mu_x

# Scatterplot of the relationship between HRs and wins
Teams %>% filter(yearID %in% 1917:2017) %>%
  mutate(HR_per_game = HR / G, wins_per_game = W / G) %>%
  ggplot(aes(HR_per_game, wins_per_game)) + 
  geom_point(alpha = 0.5) +
  geom_abline(intercept = b, slope = m)

# Regression line computations for BBs and wins
bases_on_balls <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(BB_per_game = BB / G) %>% 
  select(BB_per_game)

mu_x_BB <- sapply(bases_on_balls, mean)
mu_y <- sapply(wins, mean)
s_x_BB <- sapply(bases_on_balls, sd)
s_y <- sapply(wins, sd)
r <- cor(bases_on_balls, wins)
m <- r * s_y/s_x_BB
b <- mu_y - m*mu_x_BB

# Scatterplot of the relationship between BBs and wins
Teams %>% filter(yearID %in% 1917:2017) %>%
  mutate(BB_per_game = BB / G, wins_per_game = W / G) %>%
  ggplot(aes(BB_per_game, wins_per_game)) + 
  geom_point(alpha = 0.5) +
  geom_abline(intercept = b, slope = m)

# Regression line computations for singles and wins
singles <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(singles_per_game = (H-HR-X2B-X3B) / G) %>% 
  select(singles_per_game)

mu_x_S <- sapply(singles, mean)
mu_y <- sapply(wins, mean)
s_x_S <- sapply(singles, sd)
s_y <- sapply(wins, sd)
r <- cor(singles, wins)
m <- r * s_y/s_x_S
b <- mu_y - m * mu_x_S

# Scatterplot of the relationship between singles bases and wins
Teams %>% filter(yearID %in% 1917:2017) %>%
  mutate(singles_per_game = (H-HR-X2B-X3B) / G, wins_per_game = W / G) %>%
  ggplot(aes(singles_per_game, wins_per_game)) + 
  geom_point(alpha = 0.5) +
  geom_abline(intercept = b, slope = m)

# Regression line computations for doubles and wins
doubles <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(doubles_per_game = X2B / G) %>% 
  select(doubles_per_game)

mu_x_D <- sapply(doubles, mean)
mu_y <- sapply(wins, mean)
s_x_D <- sapply(doubles, sd)
s_y <- sapply(wins, sd)
r <- cor(doubles, wins)
m <- r * s_y/s_x_D
b <- mu_y - m * mu_x_D

# Scatterplot of the relationship between double bases and wins
Teams %>% filter(yearID %in% 1917:2017) %>%
  mutate(doubles_per_game = X2B / G, wins_per_game = W / G) %>%
  ggplot(aes(doubles_per_game, wins_per_game)) + 
  geom_point(alpha = 0.5) +
  geom_abline(intercept = b, slope = m)

# Regression line computations for triples and wins
triples <- Teams %>% 
  filter(yearID %in% 1917:2017 ) %>% 
  mutate(triples_per_game = X3B / G) %>% 
  select(triples_per_game)

mu_x_T <- sapply(triples, mean)
mu_y <- sapply(wins, mean)
s_x_T <- sapply(triples, sd)
s_y <- sapply(wins, sd)
r <- cor(triples, wins)
m <- r * s_y/s_x_T
b <- mu_y - m * mu_x_T

# Scatterplot of the relationship between triples bases and wins
Teams %>% filter(yearID %in% 1917:2017) %>%
  mutate(triples_per_game = X3B / G, wins_per_game = W / G) %>%
  ggplot(aes(triples_per_game, wins_per_game)) + 
  geom_point(alpha = 0.5) +
  geom_abline(intercept = b, slope = m)

# Compute the Slope of the regression line for BB
bb_slope <- Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(BB_per_game = BB/G, wins_per_game = W/G) %>% 
  lm(wins_per_game ~ BB_per_game, data = .) %>% 
  .$coef %>%
  .[2]
bb_slope

# Compute the Slope of the regression line for singles
singles_slope <- Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(singles_per_game = (H-HR-X2B-X3B) / G, wins_per_game = W/G) %>% 
  lm(wins_per_game ~ singles_per_game, data = .) %>% 
  .$coef %>%
  .[2]
singles_slope

# Compute the Slope of the regression line for doubles
doubles_slope <- Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(doubles_per_game = X2B /G, wins_per_game = W/G) %>% 
  lm(wins_per_game ~ doubles_per_game , data = .) %>% 
  .$coef %>%
  .[2]
doubles_slope

# Compute the Slope of the regression line for triples
triples_slope <- Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(triples_per_game = X3B /G, wins_per_game = W/G) %>% 
  lm(wins_per_game ~ triples_per_game, data = .) %>% 
  .$coef %>%
  .[2]
triples_slope

# Compute the Slope of the regression line for homeruns
bb_slope <- Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(HR_per_game = HR/G, wins_per_game = W/G) %>% 
  lm(wins_per_game ~ HR_per_game, data = .) %>% 
  .$coef %>%
  .[2]
bb_slope

# calculate correlation between all variables (BB, singles, doubles, triples, HR)
Teams %>% 
  filter(yearID %in% 1917:2017) %>% 
  mutate(BB = BB/W, S = (H-HR-X2B-X3B)/W, D = X2B/W, T = X3B/W, HR = HR/W) %>%  
  summarize(cor(BB, S), cor(S, D), cor(D, T), cor(T, HR))